package com.example.myapplication;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.MediaRecorder;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.support.v4.app.NotificationCompat;
import android.support.v4.provider.DocumentFile;
import android.util.Log;
import android.widget.Toast;

public class RecordService extends Service {
    private MediaRecorder recorder;
    private String phoneNumber;

    private DocumentFile file;
    private boolean onCall = false;
    private boolean recording = false;
    private boolean onForeground = false;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        UserPreferences.init(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
                    startRecording();
    }


    private void startRecording() {
        Log.d(Constants.TAG, "RecordService startRecording");

        //Inorder to record the audio with minimum sound interference we can use any of the three and need to find the best aftr tetsing
        //1)use audiosource VOICE_DOWNLINK
        //2)use audiosource VOICE_RECOGNITION :will record only Microphone audio source tuned for voice recognition.
        //3)use audio format with sample rate of 8000

        //mediaRecorder = new MediaRecorder();
        //mediaRecorder.setAudioSource(MediaRecorder.AudioSource.VOICE_DOWNLINK);
        //mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        //mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);


        try {

            // Setup a recorder
            final AudioRecord audioRecorder = new AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.VOICE_DOWNLINK)
                    .setBufferSizeInBytes(1024)
                    .setAudioFormat(new AudioFormat.Builder()
                            .setSampleRate(8000)
                            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .build())
                    .build();

            audioRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            audioRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

            file = FileHelper.getFile(this, phoneNumber);
            ParcelFileDescriptor fd = getContentResolver()
                    .openFileDescriptor(file.getUri(), "w");
            if (fd == null)
                throw new Exception("Failed open recording file.");
            audioRecorder.setOutputFile(fd.getFileDescriptor());

            audioRecorder.setOnErrorListener((mr, what, extra) -> {
                Log.e(Constants.TAG, "OnErrorListener " + what + "," + extra);
                terminateAndEraseFile();
            });

            audioRecorder.setOnInfoListener((mr, what, extra) -> {
                Log.e(Constants.TAG, "OnInfoListener " + what + "," + extra);
                terminateAndEraseFile();
            });

            audioRecorder.prepare();

            // Sometimes the recorder takes a while to start up
            Thread.sleep(2000);

            audioRecorder.start();
            recording = true;

        } catch (Exception e) {
            Log.e(Constants.TAG, "Failed to set up recorder.", e);
            terminateAndEraseFile();
            Toast toast = Toast.makeText(this,
                    this.getString(R.string.record_impossible),
                    Toast.LENGTH_LONG);
            toast.show();
        }
    }

}
